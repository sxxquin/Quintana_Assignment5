# serena quintana, , cs 478, assignment 5, 5-02-21

# directories import
import socket
from datetime import date

# establish the host and ports
_HOST = '127.0.0.1'
_PORT = 65432

# the first name, assignment name and date
print('\n')
print("Rock, Paper, Scissors; Classification Server")
print("Serena Quintana")
print(date.today())

#loop while sends back that client is online and makes sure that server is up before the client starts
while True:
    #this is where it rescives input from the user
    _COMMAND = input('>> client ').lower()

    #if the server is not up then this displays
    if _COMMAND == 'help':
        print('PLEASE MAKE SURE SERVER IS RUNNING BEFORE U BEGIN CLIENT')
        print("\'quit\' ends program")

    #when user quits
    elif _COMMAND == 'quit':
        break

    elif _COMMAND == '':
        #start screen that displays name and title of assignmmetn as well as date
        print('\n')
        print("Rock, Paper, Scissors; Classification Server")
        print("Serena Quintana")
        print(date.today())

    #clients begins to predict
    else:
        #server connection established to socket
        _SOCKET = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _SOCKET.connect((_HOST, _PORT))

        #when user inputs image it is recieved and open
        _FILE = open(_COMMAND, 'rb')
        _DATA = _FILE.read(1024)

        #search through file and send data to the server
        while (_DATA):
            _SOCKET.send(_DATA)
            _DATA = _FILE.read(1024)

        #image recieved
        print("Image Sent To Server.")

        #socketcloses
        _SOCKET.shutdown(socket.SHUT_WR)

        #server prints result
        _RESULT = _SOCKET.recv(1024).decode()
        print(_RESULT)

        #socket closed connection ends
        _SOCKET.close()